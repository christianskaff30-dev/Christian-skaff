AURELLE — THE EVERYDAY EDIT | NOTION WORKSPACE KIT

This kit is an import-ready Notion template starter package.

FOLDERS
- Pages: Markdown pages to import into Notion.
- Databases: CSV files to import as Notion databases.

IMPORTANT
This package does not automatically create a workspace in your Notion account.
Import the Markdown pages and CSV databases, then follow "04 - DATABASE SETUP.md"
to configure property types, relations, formulas and linked database views.

RECOMMENDED IMPORT ORDER
1. Import all CSV files from Databases.
2. Import all Markdown files from Pages.
3. Configure database property types using 09 - DATABASE SETUP.md.
4. Create the relations.
5. Build the linked views on 01 - HOME DASHBOARD.md.
6. Add your preferred cover, icons and brand styling.

DESIGN PALETTE
Warm cream #F7F1E8
Soft beige #E5D7C5
Champagne gold #B49363
Deep brown #514438
Taupe #827466

PROPOSED RETAIL POSITIONING
AURELLE — THE EVERYDAY EDIT
Premium Notion productivity workspace for students and young professionals.
Suggested launch price: USD 19.99 (to be tested; not a market-validated price).

CUSTOMER DEVICE EXPERIENCE
Notion workspace is primarily designed for desktop setup and use, with responsive access through Notion mobile apps.
