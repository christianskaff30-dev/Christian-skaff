# LIFE ADMIN

*The little details that keep life running.*

Import `Life Admin.csv`.

Use this database for:
- Renewals and subscriptions
- Personal appointments
- Important documents
- Household reminders
- Gifts and occasions
- Admin tasks

Create views:
- Upcoming: Due date within the next month
- Overdue: Due date before today and Status is not Done
- By category: Board grouped by Category

Suggested categories:
Documents · Subscription · Appointment · Home · Personal · Other
