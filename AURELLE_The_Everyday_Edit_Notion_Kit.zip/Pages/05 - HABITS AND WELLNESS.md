# HABITS & WELLNESS

*Small actions, repeated with intention.*

## Habits database

Import `Habits.csv`. Create:
- Active habits: Active is checked
- By area: Board grouped by Area

Suggested areas:
Wellness · Study · Work · Personal · Home

## Habit Log database

Import `Habit Log.csv`. Create a table or calendar view:
- Calendar by Date
- Group by Habit
- Filter Completed is checked

For a weekly habit review, filter Date to this week and review each habit's entries.

## Weekly check-in

- What gave me energy?
- What drained my energy?
- Which habit felt easiest?
- What would make next week feel more balanced?

This section is for general personal organization, not medical tracking or advice.
