# AURELLE HOME

*Your life, beautifully organized.*

> Make room for what matters today.

## TODAY

Create a linked view of **Tasks**:
- Filter: `Due date` is today
- Filter: `Status` is not Done
- Sort: `Priority` descending, then `Due date` ascending
- View: List or compact table

## THIS WEEK

Create a second linked view of **Tasks**:
- Filter: `Due date` is within this week
- Filter: `Status` is not Done
- Sort: `Due date` ascending
- View: Board grouped by Status or Calendar

## QUICK ACCESS

Add page links to:
- Tasks & Calendar
- Work & Study
- Finance
- Habits & Wellness
- Goals & Growth
- Notes Library
- Life Admin

## ACTIVE PROJECTS

Create a linked view of **Projects**:
- Filter: `Status` is In progress
- Sort: `Due date` ascending
- View: Gallery or Board

## GOALS IN FOCUS

Create a linked view of **Goals**:
- Filter: `Status` is Active
- View: Gallery or List

## MONTHLY MONEY SNAPSHOT

Create linked views of **Transactions**:
- Filter: `Date` is within this month
- Group by: `Type`
- Calculate: Sum of `Amount`
- View: Table

## HABIT CHECK-IN

Create a linked view of **Habits**:
- Filter: `Active` is checked
- View: List

## A NOTE TO MYSELF

Add a callout block with one intention for the current season.

---

### Suggested dashboard layout

Use two columns:
- Left: Today, This Week, Habit Check-in
- Right: Active Projects, Goals in Focus, Monthly Money Snapshot

Keep the top section short: one welcome line, today's date, and 3–5 quick links.
