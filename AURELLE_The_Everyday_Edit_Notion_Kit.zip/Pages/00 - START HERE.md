# AURELLE — THE EVERYDAY EDIT

**Your life. Your work. Your goals. One space.**

Welcome to your personal productivity workspace. This is a Notion template designed for young professionals and university students who want one calm, organized place for everyday life.

## Set up your workspace

1. Import each CSV in the `Databases` folder into Notion using **Settings → Import → CSV** or the Import option in your workspace.
2. Import the pages in this `Pages` folder using Notion's Markdown import.
3. Open the imported database pages and set the property types listed in `04 - DATABASE SETUP.md`.
4. Create relations between the databases where indicated.
5. Build the linked views on the Home Dashboard using `01 - HOME DASHBOARD.md`.
6. Customize the sample views, categories, and cover to make the workspace yours.

## What is included

- Home dashboard
- Tasks and calendar
- Work and study projects
- Finance tracker
- Habits and wellness
- Goals and personal growth
- Notes library
- Life administration

## Important

This kit contains import-ready Notion page content and database CSV structures. It does not automatically create a workspace in your Notion account. Importing and connecting the databases is part of setup. Database relations, formulas, views, buttons and automations need to be configured inside Notion.

## AURELLE design direction

- Warm cream: `#F7F1E8`
- Soft beige: `#E5D7C5`
- Champagne gold: `#B49363`
- Deep brown: `#514438`
- Taupe: `#827466`

Use a clean serif heading style, generous spacing, and simple icons. Keep the dashboard uncluttered.
