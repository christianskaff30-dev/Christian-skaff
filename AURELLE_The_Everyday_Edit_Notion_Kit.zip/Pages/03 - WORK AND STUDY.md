# WORK & STUDY

*Make progress visible.*

## Projects database

Import `Projects.csv`. Use it for work projects, university courses, assignments, applications and personal projects.

Create these views:
- Active projects: Status is In progress
- By type: Board grouped by Type
- Upcoming deadlines: Due date ascending
- Completed: Status is Done

Suggested Type options:
University · Work · Personal · Career

Suggested Status options:
Not started · In progress · On hold · Done

## Project page template

For each new project, add these sections:

### Outcome
What does finished look like?

### Key milestones
- Milestone 1
- Milestone 2
- Milestone 3

### Next actions
Link the relevant tasks from the Tasks database.

### Resources
Add links, documents and useful references.

### Notes and decisions
Keep important context here.

## Study session template

- Subject / course:
- Topic:
- Session goal:
- Key concepts:
- Questions to revisit:
- Next study action:
