# GOALS & GROWTH

*Turn intentions into meaningful next steps.*

Import `Goals.csv`.

## Suggested views

### Active goals
Filter Status is Active.

### By life area
Board grouped by Area.

### Target dates
Calendar using Target date.

## Goal page template

### Why this matters
Why is this goal important to me?

### What success looks like
Describe a clear outcome.

### Milestones
- First milestone:
- Second milestone:
- Final milestone:

### Next action
What is the smallest useful step I can take?

### Reflection
What is working? What needs to change?

Suggested Areas:
Career · University · Finance · Health · Relationships · Personal
