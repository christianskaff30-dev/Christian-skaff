# NOTES & LIBRARY

*Keep useful ideas close.*

Import `Notes Library.csv`.

Suggested Type options:
Meeting · Class notes · Reading notes · Idea · Resource · Journal

Create views:
- All notes: Table sorted by Created descending
- Class notes: Filter Type is Class notes
- Ideas: Filter Type is Idea
- Resources: Filter Type is Resource

## Reusable note template

### Summary
What is this about?

### Key points
- 
- 
- 

### Useful links
Add reference links and resources.

### Next action
Is there anything to do with this note?
