# DATABASE SETUP GUIDE

Use these property types after importing the CSV files.

## Tasks
- Task: Title
- Status: Status or Select
- Priority: Select
- Due date: Date
- Area: Select
- Type: Select
- Project: Relation → Projects
- Goal: Relation → Goals
- Notes: Text

## Projects
- Project: Title
- Type: Select
- Status: Status or Select
- Start date: Date
- Due date: Date
- Priority: Select
- Outcome: Text
- Notes: Text

## Calendar
- Event: Title
- Date: Date
- End date: Date
- Type: Select
- Location: Text
- Related project: Relation → Projects
- Notes: Text

## Transactions
- Date: Date
- Description: Title
- Type: Select (Income / Expense)
- Category: Select
- Amount: Number (currency format)
- Account: Select
- Month: Select or formula
- Notes: Text

## Habits
- Habit: Title
- Frequency: Select
- Area: Select
- Target: Number
- Active: Checkbox
- Notes: Text

## Habit Log
- Date: Date
- Habit: Relation → Habits
- Completed: Checkbox
- Notes: Text

## Goals
- Goal: Title
- Area: Select
- Status: Status or Select
- Target date: Date
- Metric: Text
- Target value: Number
- Current value: Number
- Why it matters: Text
- Next step: Text

## Notes Library
- Title: Title
- Type: Select
- Created: Date
- Related project: Relation → Projects
- Tags: Multi-select
- Content: Text

## Life Admin
- Item: Title
- Category: Select
- Due date: Date
- Status: Status or Select
- Reminder date: Date
- Notes: Text

## Optional formulas to add inside Notion

**Days until due** (add to Tasks as a Formula property):
`if(empty(prop("Due date")), "", dateBetween(prop("Due date"), today(), "days"))`

**Remaining goal amount** (add to Goals as a Formula property):
`max(0, prop("Target value") - prop("Current value"))`

**Net transaction amount** (add to Transactions as a Formula property):
`if(prop("Type") == "Expense", -prop("Amount"), prop("Amount"))`

Formula syntax and supported functions can change; if Notion flags a formula, use its formula editor to adjust it.

## Relations to create
1. Tasks → Projects
2. Tasks → Goals
3. Calendar → Projects
4. Habit Log → Habits
5. Notes Library → Projects

CSV import creates database tables but does not automatically create Notion relations, formulas, rollups, linked views or buttons. Add these after importing.
