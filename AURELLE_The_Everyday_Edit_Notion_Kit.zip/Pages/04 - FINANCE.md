# FINANCE

*Give every dollar a direction.*

Import `Transactions.csv` and set up the properties as described in the database setup guide.

## Recommended views

### All transactions
Table sorted by Date descending.

### Income
Filter Type is Income.

### Expenses
Filter Type is Expense.

### By category
Board grouped by Category.

### This month
Filter Date is within this month; calculate the sum of Amount.

## Suggested categories

Housing · Food · Transport · Education · Subscriptions · Shopping · Health · Entertainment · Travel · Other

## Monthly money check-in

- Income this month:
- Essential expenses:
- Flexible expenses:
- Savings:
- One spending choice I feel good about:
- One adjustment for next month:

## Note

Enter expenses and income as positive amounts, and use the Type field to distinguish Income from Expense. For totals, use database views grouped by Type and calculate the sum of Amount. If you want an automatic net balance, add a formula property inside Notion.
