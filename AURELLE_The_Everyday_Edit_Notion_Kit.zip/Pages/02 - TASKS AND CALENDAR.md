# TASKS & CALENDAR

*Know what needs your attention—and when.*

## Tasks database

Import `Tasks.csv` and create these views:

### Inbox
- Filter: Status is Not started
- Sort: Created time descending (add Created time property if desired)

### Today
- Filter: Due date is today
- Filter: Status is not Done

### This week
- Filter: Due date is within this week
- Sort: Due date ascending

### By status
- Board grouped by Status

### Calendar
- Calendar view using Due date

## Suggested Status options
Not started · In progress · Waiting · Done

## Suggested Priority options
High · Medium · Low

## Suggested Area options
Work · University · Personal · Finance · Health · Home

## Calendar database

Import `Calendar.csv` for appointments, classes, meetings, exams, deadlines and personal events. Create:
- Calendar view by Date
- Upcoming list sorted by Date
- Events by Type board

Use the Tasks database for actions. Use Calendar for time-specific events.
